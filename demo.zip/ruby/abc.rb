
def test1(&block)
   block.call
end
test1 { puts "Hello World!"}