require 'tk'

root = TkRoot.new { title "Hello, World!" 
 
}
TkLabel.new(root) do
   text 'Hello, World!'
   width 100
   height 25
   pack { padx 150 ; pady 150; side 'left' }
end
Tk.mainloop