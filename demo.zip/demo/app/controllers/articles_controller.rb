class ArticlesController < ApplicationController
  def index
    @article = { title: "Best Food", body: "Pizza, donuts, potatoes" }
  end
end
